#!/usr/bin/env python3
"""LogoPilot · SVG → PNG 渲染

用本机无头 Chrome 渲染 SVG，保留透明背景。不依赖 cairosvg / ImageMagick。

用法：
    # 单张，指定尺寸与背景
    python3 render_svg.py mark.svg --size 1024 --out preview/mark.png
    python3 render_svg.py mark.svg --size 512 --bg dark --out preview/mark-dark.png

    # favicon 全套（16/32/48/64/128/256）
    python3 render_svg.py mark.svg --favicon --out-dir favicon/

    # 批量：把目录里所有 svg 渲成同名 png
    python3 render_svg.py svg/ --out-dir preview/ --size 512

    # 多尺寸套图
    python3 render_svg.py mark.svg --sizes 256,512,1024 --out-dir png/
"""

from __future__ import annotations

import argparse
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path

PNG_SIG = b"\x89PNG\r\n\x1a\n"

# ⚠️ Chrome 无头模式有**最小窗口尺寸**：窗口小于它时，页面按最小尺寸渲染，
#    而 --screenshot 只截左上角一块 —— 结果是"图是空的/只有一角"。
#
#    实测（macOS · Chrome，用一个已知位置的矩形反推墨迹坐标）：
#      window=256 → 墨迹 x 0.695..1.000   ✗ 错位
#      window=480 → 墨迹 x 0.271..0.771   ✗ 仍错位
#      window=512 → 墨迹 x 0.250..0.750   ✓ 正确
#      window=800 → 墨迹 x 0.250..0.750   ✓ 正确
#    所以 SAFE_MIN 取 512。小尺寸不能直接截，必须先按整数倍放大渲染，
#    再用纯 Python 做面积平均（box filter）缩放。
#
#    这个值可以用 --safe-min 覆盖，换机器/换浏览器版本时先跑一次校准。
SAFE_MIN = 512

CHROME_CANDIDATES = [
    # macOS
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    # Windows（用 %LOCALAPPDATA% 展开，避免写死用户名）
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
    os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
    os.path.expandvars(r"%PROGRAMFILES(X86)%\Microsoft\Edge\Application\msedge.exe"),
    # Linux / 通用：靠 PATH 找
    shutil.which("google-chrome") or "",
    shutil.which("google-chrome-stable") or "",
    shutil.which("chromium") or "",
    shutil.which("chromium-browser") or "",
    shutil.which("chrome") or "",
    shutil.which("msedge") or "",
]

FAVICON_SIZES = [16, 32, 48, 64, 128, 256]

BG_PRESETS = {
    "transparent": None,
    "light": "#ffffff",
    "dark": "#111111",
    "paper": "#f7f5f0",
}


def find_chrome() -> str:
    env = os.environ.get("CHROME_PATH")
    if env and Path(env).exists():
        return env
    for c in CHROME_CANDIDATES:
        if c and Path(c).exists():
            return c
    raise SystemExit(
        "找不到 Chrome / Chromium。请安装 Google Chrome，或设置环境变量 CHROME_PATH 指向浏览器可执行文件。"
    )


def build_html(svg_text: str, bg: str | None, padding_pct: float, scale: float) -> str:
    body_bg = bg if bg else "transparent"
    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<style>
  html, body {{ margin:0; padding:0; width:100%; height:100%; overflow:hidden; background:{body_bg}; }}
  .wrap {{ width:100%; height:100%; box-sizing:border-box; padding:{padding_pct}%; display:block; }}
  .wrap > svg {{ width:100% !important; height:100% !important; display:block; }}
</style></head>
<body><div class="wrap">{svg_text}</div></body></html>"""


# ───────────────────────── 纯标准库 PNG 缩放 ─────────────────────────
# 为什么不用 PIL / ImageMagick：本机不一定有，而 favicon 导出是刚需。
# 只支持 8bit RGB / RGBA 非隔行 PNG —— 正好是 Chrome --screenshot 的输出格式。

def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c


def png_read(path: Path) -> tuple[int, int, int, bytearray]:
    """读 PNG → (宽, 高, 通道数, 像素字节)。"""
    d = path.read_bytes()
    if d[:8] != PNG_SIG:
        raise ValueError(f"{path} 不是 PNG")
    pos, idat = 8, bytearray()
    w = h = ch = None
    while pos < len(d):
        ln = struct.unpack(">I", d[pos:pos + 4])[0]
        typ = d[pos + 4:pos + 8]
        body = d[pos + 8:pos + 8 + ln]
        if typ == b"IHDR":
            w, h, bd, ct, _comp, _filt, inter = struct.unpack(">IIBBBBB", body)
            if bd != 8 or inter != 0 or ct not in (2, 6):
                raise ValueError(f"不支持的 PNG：bitdepth={bd} colortype={ct} interlace={inter}")
            ch = 4 if ct == 6 else 3
        elif typ == b"IDAT":
            idat += body
        elif typ == b"IEND":
            break
        pos += 12 + ln

    raw = zlib.decompress(bytes(idat))
    stride = w * ch
    out = bytearray(h * stride)
    prev = bytes(stride)
    p = 0
    for y in range(h):
        f = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if f == 1:                       # Sub
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif f == 2:                     # Up
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif f == 3:                     # Average
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 255
        elif f == 4:                     # Paeth
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + _paeth(a, prev[i], prev[i - ch] if i >= ch else 0)) & 255
        out[y * stride:(y + 1) * stride] = line
        prev = bytes(line)
    return w, h, ch, out


def png_write(path: Path, w: int, h: int, ch: int, pixels: bytes | bytearray) -> None:
    """写 8bit RGB / RGBA PNG（全部用 filter 0，无需自适应）。"""
    ct = 6 if ch == 4 else 2
    stride = w * ch
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += pixels[y * stride:(y + 1) * stride]

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    path.write_bytes(
        PNG_SIG
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, ct, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        + chunk(b"IEND", b"")
    )


def png_box_downscale(src: Path, dst: Path, k: int) -> tuple[int, int]:
    """整数倍面积平均缩放（box filter），分水平/垂直两趟，保留 alpha。

    面积平均而不是最近邻：favicon 缩到 16px 时，最近邻会丢笔画，
    面积平均才能反映"真实缩小后还能不能认出来"。
    """
    w, h, ch, px = png_read(src)
    nw, nh = w // k, h // k
    kc = k * ch

    # 水平趟：(w,h) → (nw,h)
    mid = bytearray(nw * h * ch)
    for y in range(h):
        row = y * w * ch
        mrow = y * nw * ch
        for x in range(nw):
            seg = px[row + x * kc: row + (x + 1) * kc]
            m = mrow + x * ch
            for c in range(ch):
                mid[m + c] = sum(seg[c::ch]) // k

    # 垂直趟：(nw,h) → (nw,nh)
    out = bytearray(nw * nh * ch)
    mstride = nw * ch
    for y in range(nh):
        acc = [0] * mstride
        for dy in range(k):
            base = (y * k + dy) * mstride
            seg = mid[base:base + mstride]
            for i in range(mstride):
                acc[i] += seg[i]
        o = y * mstride
        for i in range(mstride):
            out[o + i] = acc[i] // k

    png_write(dst, nw, nh, ch, out)
    return nw, nh


def render_one(
    chrome: str,
    svg_path: Path,
    out_path: Path,
    size: int,
    bg: str | None,
    padding_pct: float,
    timeout: int = 60,
    safe_min: int = SAFE_MIN,
) -> bool:
    svg_text = svg_path.read_text(encoding="utf-8", errors="replace")
    html = build_html(svg_text, bg, padding_pct, 1.0)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    # 小尺寸不能直接截：Chrome 无头模式窗口小于 safe_min 时只截左上角。
    # 先按整数倍放大渲染，再面积平均缩回来。
    k = 1 if size >= safe_min else -(-safe_min // size)
    render_size = size * k

    with tempfile.TemporaryDirectory(prefix="logopilot-") as td:
        tmp_html = Path(td) / "page.html"
        tmp_html.write_text(html, encoding="utf-8")
        tmp_png = Path(td) / "shot.png"

        cmd = [
            chrome,
            "--headless",
            "--disable-gpu",
            "--no-sandbox",
            "--hide-scrollbars",
            "--disable-dev-shm-usage",
            "--force-device-scale-factor=1",
            "--virtual-time-budget=3000",
            f"--window-size={render_size},{render_size}",
            f"--screenshot={tmp_png}",
            "--default-background-color=00000000" if bg is None else "--default-background-color=FFFFFFFF",
            tmp_html.as_uri(),
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)

        if not tmp_png.exists() or tmp_png.stat().st_size == 0:
            print(
                f"  ✘ 渲染失败：{svg_path.name} → {size}px\n"
                f"    {proc.stderr.strip().splitlines()[-1] if proc.stderr.strip() else '无错误输出'}",
                file=sys.stderr,
            )
            return False

        if k > 1:
            try:
                png_box_downscale(tmp_png, out_path, k)
            except ValueError as e:
                print(f"  ✘ 缩放失败：{svg_path.name} → {size}px（{e}）", file=sys.stderr)
                return False
        else:
            shutil.move(str(tmp_png), str(out_path))

    extra = f"，{render_size}px 渲染后 1/{k} 面积平均" if k > 1 else ""
    print(f"  ✔ {out_path}  ({size}×{size}{extra})")
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot SVG → PNG 渲染（无头 Chrome，保留透明背景）")
    ap.add_argument("input", help="SVG 文件或包含 SVG 的目录")
    ap.add_argument("--out", help="单张输出路径（仅当 input 是单个文件时可用）")
    ap.add_argument("--out-dir", help="输出目录（批量 / 多尺寸 / favicon 时使用）")
    ap.add_argument("--size", type=int, default=1024, help="输出边长（默认 1024）")
    ap.add_argument("--sizes", help="多尺寸，逗号分隔，例如 256,512,1024")
    ap.add_argument("--favicon", action="store_true", help=f"输出 favicon 套图 {FAVICON_SIZES}")
    ap.add_argument(
        "--bg",
        default="transparent",
        help="背景：transparent / light / dark / paper / 任意 #hex（默认 transparent）",
    )
    ap.add_argument("--padding", type=float, default=0.0, help="四周留白百分比，例如 10 表示四周各留 10%%")
    ap.add_argument("--safe-min", type=int, default=SAFE_MIN,
                    help=f"无头浏览器最小可渲染窗口边长（默认 {SAFE_MIN}）；换机器时可用它校准")
    args = ap.parse_args()

    bg = BG_PRESETS.get(args.bg, args.bg)
    if bg is not None and not bg.startswith("#"):
        raise SystemExit(f"--bg 取值无效：{args.bg}")

    chrome = find_chrome()
    src = Path(args.input)

    if src.is_file():
        files = [src]
    elif src.is_dir():
        files = sorted(src.rglob("*.svg"))
        if not files:
            raise SystemExit(f"{src} 里没有 .svg 文件")
    else:
        raise SystemExit(f"找不到：{src}")

    if args.favicon:
        sizes = FAVICON_SIZES
    elif args.sizes:
        sizes = [int(x) for x in args.sizes.split(",") if x.strip()]
    else:
        sizes = [args.size]

    single = len(files) == 1 and len(sizes) == 1
    if single and not args.out and not args.out_dir:
        raise SystemExit("单张渲染需要 --out 或 --out-dir")

    ok = 0
    fail = 0
    for f in files:
        for s in sizes:
            if args.out and single:
                out = Path(args.out)
            else:
                out_dir = Path(args.out_dir or "preview")
                suffix = f"-{s}" if len(sizes) > 1 else ""
                out = out_dir / f"{f.stem}{suffix}.png"
            if render_one(chrome, f, out, s, bg, args.padding, safe_min=args.safe_min):
                ok += 1
            else:
                fail += 1

    print(f"\n完成：{ok} 张成功" + (f"，{fail} 张失败" if fail else ""))
    return 1 if fail else 0


if __name__ == "__main__":
    sys.exit(main())
