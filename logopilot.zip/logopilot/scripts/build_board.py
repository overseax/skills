#!/usr/bin/env python3
"""LogoPilot · 方向对比板生成

把一个目录里的 logo SVG 组成一张自包含的 HTML 对比板，用于阶段 3/4 的评审：
浅底 / 深底 / 单色 / 反白 / 多尺寸 一次看全。

用法：
    python3 build_board.py svg/ --brand "品牌名" --out board.html
    python3 build_board.py svg/ --brand "品牌名" --meta meta.json --out board.html

meta.json 结构（可选，用来给方向加名字和说明）：
    {
      "brand": "品牌名",
      "tagline": "一句话定位",
      "directions": {
        "d1": {"name": "方向名", "concept": "概念一句话", "notes": "构造说明", "pick": true}
      }
    }
"""

from __future__ import annotations

import argparse
import html
import json
import re
from datetime import date
from pathlib import Path

XML_DECL = re.compile(r"<\?xml[^>]*\?>")
ROOT_WH = re.compile(r'(<svg\b[^>]*?)\s(?:width|height)="[^"]*"', re.IGNORECASE)
DIR_PREFIX = re.compile(r"^(d\d+)[-_]", re.IGNORECASE)

VARIANT_LABELS = [
    ("primary", "主标"),
    ("mark", "纯图形"),
    ("wordmark", "字标"),
    ("lockup-horizontal", "横排锁定"),
    ("lockup-vertical", "竖排锁定"),
    ("mono-black", "单色黑"),
    ("mono-white", "反白"),
    ("inverse", "反白"),
    ("favicon", "小尺寸简化"),
]

SIZE_STEPS = [16, 24, 32, 48, 64]


def sanitize(svg_text: str, uid: str) -> str:
    """去掉 XML 声明与根节点固定宽高，并把内部 id 加前缀避免多图冲突。"""
    t = XML_DECL.sub("", svg_text).strip()
    m = re.search(r"<svg\b[^>]*>", t, re.IGNORECASE | re.DOTALL)
    if m:
        open_tag = m.group(0)
        cleaned = re.sub(r'\s(?:width|height)\s*=\s*"[^"]*"', "", open_tag, flags=re.IGNORECASE)
        t = t[: m.start()] + cleaned + t[m.end() :]
    # id 命名空间化
    ids = set(re.findall(r'\bid="([^"]+)"', t))
    for i in sorted(ids, key=len, reverse=True):
        safe = f"{uid}-{i}"
        t = t.replace(f'id="{i}"', f'id="{safe}"')
        t = t.replace(f"url(#{i})", f"url(#{safe})")
        t = t.replace(f'href="#{i}"', f'href="#{safe}"')
        t = t.replace(f"xlink:href=\"#{i}\"", f'xlink:href="#{safe}"')
    return t


def variant_kind(stem: str) -> tuple[str, str]:
    """从文件名推断变体类型，返回 (key, 展示标签)。"""
    s = stem.lower()
    for key, label in VARIANT_LABELS:
        if key in s:
            return key, label
    return "other", "其他"


def collect(svg_dir: Path):
    groups: dict[str, list[Path]] = {}
    for f in sorted(svg_dir.rglob("*.svg")):
        m = DIR_PREFIX.match(f.stem)
        key = m.group(1).lower() if m else "all"
        groups.setdefault(key, []).append(f)
    return dict(sorted(groups.items()))


def esc(s: str) -> str:
    return html.escape(str(s), quote=True)


def card(dkey: str, files: list[Path], meta: dict) -> str:
    info = (meta.get("directions") or {}).get(dkey, {})
    name = info.get("name") or (f"方向 {dkey.upper()}" if dkey != "all" else "全部方案")
    concept = info.get("concept") or ""
    notes = info.get("notes") or ""
    pick = info.get("pick")

    by_kind: dict[str, Path] = {}
    for f in files:
        k, _ = variant_kind(f.stem)
        by_kind.setdefault(k, f)

    ordered = [k for k, _ in VARIANT_LABELS if k in by_kind]
    others = [k for k in by_kind if k not in ordered]
    ordered += others

    label_map = dict(VARIANT_LABELS)

    # 主视觉：优先 primary，其次 mark，其次第一个
    hero_kind = "primary" if "primary" in by_kind else ("mark" if "mark" in by_kind else ordered[0])
    hero = sanitize(by_kind[hero_kind].read_text(encoding="utf-8", errors="replace"), f"{dkey}-hero")

    # 变体缩略
    thumbs = []
    for k in ordered:
        if k == hero_kind:
            continue
        svg = sanitize(by_kind[k].read_text(encoding="utf-8", errors="replace"), f"{dkey}-{k}")
        bg_cls = "on-dark" if k in ("mono-white", "inverse") else "on-light"
        thumbs.append(
            f'<figure class="thumb {bg_cls}">'
            f'<div class="thumb-art">{svg}</div>'
            f'<figcaption>{esc(label_map.get(k, k))}<span class="fn">{esc(by_kind[k].name)}</span></figcaption>'
            f"</figure>"
        )

    # 多尺寸测试条：优先用纯图形（小尺寸下真正被使用的东西）
    size_kind = "mark" if "mark" in by_kind else hero_kind
    sizes = []
    for px in SIZE_STEPS:
        svg = sanitize(by_kind[size_kind].read_text(encoding="utf-8", errors="replace"), f"{dkey}-s{px}")
        sizes.append(
            f'<div class="size"><div class="size-art" style="width:{px}px;height:{px}px">{svg}</div>'
            f'<span>{px}</span></div>'
        )

    badge = '<span class="badge pick">推荐</span>' if pick else ""
    notes_html = f'<p class="notes">{esc(notes)}</p>' if notes else ""

    return f"""
  <section class="card">
    <header class="card-head">
      <h2>{esc(name)} {badge}</h2>
      {f'<p class="concept">{esc(concept)}</p>' if concept else ''}
      {notes_html}
    </header>
    <div class="hero on-light">{hero}</div>
    <div class="thumbs">{''.join(thumbs)}</div>
    <div class="sizes-row">
      <span class="sizes-label">小尺寸测试</span>
      <div class="sizes">{''.join(sizes)}</div>
    </div>
  </section>"""


def build(svg_dir: Path, meta: dict) -> str:
    groups = collect(svg_dir)
    if not groups:
        raise SystemExit(f"{svg_dir} 里没有找到 .svg 文件")

    brand = meta.get("brand") or svg_dir.resolve().parent.name
    tagline = meta.get("tagline") or ""
    today = date.today().isoformat()

    cards = "\n".join(card(k, v, meta) for k, v in groups.items())
    total = sum(len(v) for v in groups.values())

    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(brand)} · Logo 方向板</title>
<style>
  :root {{
    --bg:#f6f7f9; --card:#ffffff; --ink:#16181d; --muted:#6b7280;
    --line:#e5e7eb; --accent:#2f6df6; --dark:#111318;
    --sans:-apple-system,BlinkMacSystemFont,"PingFang SC","Helvetica Neue",Arial,sans-serif;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--ink); font-family:var(--sans);
         -webkit-font-smoothing:antialiased; }}
  .page {{ max-width:1180px; margin:0 auto; padding:48px 28px 80px; }}
  .top {{ border-bottom:1px solid var(--line); padding-bottom:24px; margin-bottom:32px; }}
  .top h1 {{ font-size:30px; margin:0 0 6px; letter-spacing:-0.02em; }}
  .top .tag {{ color:var(--muted); font-size:14px; margin:0; }}
  .top .meta {{ color:var(--muted); font-size:12px; margin-top:14px;
                display:flex; gap:18px; flex-wrap:wrap; }}
  .legend {{ background:var(--card); border:1px solid var(--line); border-radius:12px;
             padding:14px 18px; margin-bottom:28px; font-size:13px; color:var(--muted); }}
  .legend b {{ color:var(--ink); }}
  .card {{ background:var(--card); border:1px solid var(--line); border-radius:16px;
           padding:26px; margin-bottom:26px; }}
  .card-head h2 {{ font-size:19px; margin:0 0 6px; letter-spacing:-0.01em; }}
  .concept {{ margin:0 0 4px; font-size:14px; color:var(--ink); }}
  .notes {{ margin:6px 0 0; font-size:13px; color:var(--muted); line-height:1.6; }}
  .badge {{ font-size:11px; padding:2px 8px; border-radius:99px; vertical-align:middle;
            margin-left:6px; font-weight:600; }}
  .badge.pick {{ background:#e8f0ff; color:#1d4ed8; }}
  .hero {{ margin:20px 0 14px; border-radius:12px; padding:34px; display:flex;
           align-items:center; justify-content:center; min-height:230px; }}
  /* svg 自带 viewBox，用 meet 等比适配容器；不设固定宽高，避免被拉伸 */
  .hero svg, .thumb-art svg, .size-art svg {{ width:100%; height:100%; display:block; }}
  .on-light {{ background:#ffffff; border:1px solid var(--line); }}
  .on-dark {{ background:var(--dark); border:1px solid var(--dark); }}
  .on-dark figcaption {{ color:#cbd5e1; }}
  .thumbs {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(178px,1fr)); gap:12px; }}
  .thumb {{ margin:0; border-radius:10px; overflow:hidden; border:1px solid var(--line); }}
  .thumb-art {{ height:118px; display:flex; align-items:center; justify-content:center; padding:16px; }}
  .thumb figcaption {{ font-size:12px; color:var(--muted); padding:8px 10px;
                       border-top:1px solid var(--line); background:#fafbfc;
                       display:flex; justify-content:space-between; gap:8px; }}
  .thumb .fn {{ opacity:.55; font-size:11px; }}
  .sizes-row {{ margin-top:18px; padding-top:16px; border-top:1px dashed var(--line);
                display:flex; align-items:flex-end; gap:20px; flex-wrap:wrap; }}
  .sizes-label {{ font-size:12px; color:var(--muted); }}
  .sizes {{ display:flex; align-items:flex-end; gap:18px; }}
  .size {{ display:flex; flex-direction:column; align-items:center; gap:6px; }}
  .size-art {{ display:flex; align-items:center; justify-content:center; }}
  .size span {{ font-size:10px; color:var(--muted); }}
  footer {{ margin-top:36px; padding-top:20px; border-top:1px solid var(--line);
            font-size:12px; color:var(--muted); line-height:1.8; }}
  footer ol {{ margin:8px 0 0; padding-left:20px; }}
</style></head>
<body><div class="page">
  <div class="top">
    <h1>{esc(brand)} · Logo 方向板</h1>
    {f'<p class="tag">{esc(tagline)}</p>' if tagline else ''}
    <div class="meta">
      <span>生成日期 {today}</span>
      <span>{len(groups)} 个方向</span>
      <span>{total} 个 SVG</span>
      <span>LogoPilot 工作流</span>
    </div>
  </div>

  <div class="legend">
    <b>怎么看这张板：</b>大图是主标（白底）；下面一行是各变体，其中深底格是反白版；
    最下面是 16–64px 的小尺寸测试——如果 16px 就糊成一团，说明这个方向需要出简化版 favicon。
    <b>单色黑版必须成立</b>：去掉颜色还能认出来，造型才算立住。
  </div>

  {cards}

  <footer>
    <b>定稿前检查</b>
    <ol>
      <li>纯黑单色下造型是否成立</li>
      <li>16×16 下是否可辨认（或已有简化版）</li>
      <li>深色底是否有可用反白版</li>
      <li>颜色是否 ≤ 3 个</li>
      <li>字标是否为路径（不依赖字体）</li>
    </ol>
    <p>本方案由 LogoPilot 程序化生成，适合品牌方向验证；商用前请自行完成商标检索。</p>
  </footer>
</div></body></html>"""


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot 方向对比板生成")
    ap.add_argument("svg_dir", help="包含 logo SVG 的目录")
    ap.add_argument("--brand", help="品牌名")
    ap.add_argument("--tagline", help="一句话定位")
    ap.add_argument("--meta", help="meta.json 路径（可选）")
    ap.add_argument("--out", default="board.html", help="输出 HTML 路径")
    args = ap.parse_args()

    meta: dict = {}
    if args.meta:
        meta = json.loads(Path(args.meta).read_text(encoding="utf-8"))
    if args.brand:
        meta["brand"] = args.brand
    if args.tagline:
        meta["tagline"] = args.tagline

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build(Path(args.svg_dir), meta), encoding="utf-8")
    print(f"✔ 方向板已生成：{out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
