#!/usr/bin/env python3
"""LogoPilot · 场景应用模拟板生成

把 logo SVG 放进几个真实使用场景里看效果，用于阶段 4 的"挑选方案"决策：
门头招牌（深底）/ 包装（纸底）/ 头像 + App 图标 / 名片。

这是**决策材料，不是定稿**——目的是让客户看到"这个标志落到我的生意上是什么样"，
而不是只对着白底大图猜。

用法：
    python3 build_mockup.py svg/ --meta meta.json --out mockup.html
    python3 build_mockup.py svg/ --brand "品牌名" --tagline "一句话定位" --out mockup.html

meta.json 与 build_board.py 共用同一份（brand / tagline / directions）。
"""

from __future__ import annotations

import argparse
import html
import json
import re
from datetime import date
from pathlib import Path

XML_DECL = re.compile(r"<\?xml[^>]*\?>")
DIR_PREFIX = re.compile(r"^(d\d+)[-_]", re.IGNORECASE)

# 变体探测顺序：长键必须在短键之前（wordmark 不能被 mark 吃掉）
VARIANT_ORDER = [
    "lockup-horizontal", "lockup-vertical", "primary",
    "mono-black", "mono-white", "inverse", "wordmark", "mark", "favicon",
]


def sanitize(svg_text: str, uid: str) -> str:
    """去掉 XML 声明与根节点固定宽高，并把内部 id 加前缀避免多图冲突。"""
    t = XML_DECL.sub("", svg_text).strip()
    m = re.search(r"<svg\b[^>]*>", t, re.IGNORECASE | re.DOTALL)
    if m:
        open_tag = m.group(0)
        cleaned = re.sub(r'\s(?:width|height)\s*=\s*"[^"]*"', "", open_tag, flags=re.IGNORECASE)
        t = t[: m.start()] + cleaned + t[m.end():]
    ids = set(re.findall(r'\bid="([^"]+)"', t))
    for i in sorted(ids, key=len, reverse=True):
        safe = f"{uid}-{i}"
        t = t.replace(f'id="{i}"', f'id="{safe}"')
        t = t.replace(f"url(#{i})", f"url(#{safe})")
        t = t.replace(f'href="#{i}"', f'href="#{safe}"')
        t = t.replace(f'xlink:href="#{i}"', f'xlink:href="#{safe}"')
    return t


def esc(s: str) -> str:
    return html.escape(str(s), quote=True)


def collect(svg_dir: Path) -> dict[str, dict[str, Path]]:
    """→ {"d1": {"primary": Path, "mark": Path, ...}, ...}"""
    groups: dict[str, dict[str, Path]] = {}
    for f in sorted(svg_dir.rglob("*.svg")):
        m = DIR_PREFIX.match(f.stem)
        key = m.group(1).lower() if m else "all"
        stem = f.stem.lower()
        kind = "other"
        for k in VARIANT_ORDER:
            if k in stem:
                kind = k
                break
        groups.setdefault(key, {}).setdefault(kind, f)
    return dict(sorted(groups.items()))


def pick(by_kind: dict[str, Path], *candidates: str) -> Path | None:
    """按优先级取第一个存在的变体。"""
    for c in candidates:
        if c in by_kind:
            return by_kind[c]
    return None


def tiles(dkey: str, by_kind: dict[str, Path], meta: dict) -> str:
    """四个场景瓦片。缺少某个变体时降级到已存在的变体，不报错。"""
    lockup = pick(by_kind, "primary", "lockup-horizontal", "mark", "other")
    # 包装袋是竖版窄幅，优先用竖排锁定；没有才退回横排
    vertical = pick(by_kind, "lockup-vertical", "primary", "mark", "other")
    inverse = pick(by_kind, "inverse", "mono-white", "primary", "other")
    mark = pick(by_kind, "mark", "primary", "other")
    mono = pick(by_kind, "mono-black", "mark", "other")

    out = []
    for slot, path in (("vertical", vertical), ("inverse", inverse),
                       ("mark", mark), ("mono", mono)):
        if path is None:
            continue
        svg = sanitize(path.read_text(encoding="utf-8", errors="replace"), f"{dkey}-{slot}")

        if slot == "vertical":
            out.append(f'''<figure class="tile">
        <div class="scene pack"><div class="pouch">{svg}</div></div>
        <figcaption>包装 · 纸底（竖排锁定）</figcaption>
      </figure>''')
        elif slot == "inverse":
            out.append(f'''<figure class="tile">
        <div class="scene sign"><div class="signboard">{svg}</div></div>
        <figcaption>门头招牌 · 深底反白</figcaption>
      </figure>''')
        elif slot == "mark":
            out.append(f'''<figure class="tile">
        <div class="scene duo">
          <div class="avatar">{svg}</div>
          <div class="appicon">{svg}</div>
        </div>
        <figcaption>公众号头像 / App 图标</figcaption>
      </figure>''')
        else:
            out.append(f'''<figure class="tile">
        <div class="scene business">
          <div class="card">
            <div class="card-logo">{svg}</div>
            <div class="card-lines"><i></i><i></i><i class="short"></i></div>
          </div>
        </div>
        <figcaption>名片 · 单色黑</figcaption>
      </figure>''')

    info = (meta.get("directions") or {}).get(dkey, {})
    name = info.get("name") or (f"方向 {dkey.upper()}" if dkey != "all" else "全部方案")
    concept = info.get("concept") or ""

    return f'''
  <section class="dir">
    <header>
      <h2>{esc(name)}</h2>
      {f'<p class="concept">{esc(concept)}</p>' if concept else ''}
    </header>
    <div class="tiles">
      {''.join(out)}
    </div>
  </section>'''


def build(svg_dir: Path, meta: dict) -> str:
    groups = collect(svg_dir)
    if not groups:
        raise SystemExit(f"{svg_dir} 里没有找到 .svg 文件")

    brand = meta.get("brand") or svg_dir.resolve().parent.name
    tagline = meta.get("tagline") or ""
    today = date.today().isoformat()

    body = "\n".join(tiles(k, v, meta) for k, v in groups.items())

    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(brand)} · 场景应用模拟</title>
<style>
  :root {{
    --bg:#f4f5f7; --card:#fff; --ink:#16181d; --muted:#6b7280;
    --line:#e5e7eb; --kraft:#c9a97a; --dark:#14201a;
    --sans:-apple-system,BlinkMacSystemFont,"PingFang SC","Helvetica Neue",Arial,sans-serif;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--ink); font-family:var(--sans);
         -webkit-font-smoothing:antialiased; }}
  .page {{ max-width:1180px; margin:0 auto; padding:48px 28px 72px; }}
  .top {{ border-bottom:1px solid var(--line); padding-bottom:22px; margin-bottom:28px; }}
  .top h1 {{ font-size:29px; margin:0 0 6px; letter-spacing:-0.02em; }}
  .top .tag {{ color:var(--muted); font-size:14px; margin:0; }}
  .top .meta {{ color:var(--muted); font-size:12px; margin-top:12px; display:flex; gap:18px; flex-wrap:wrap; }}
  .notice {{ background:#fff8e6; border:1px solid #f0e0b0; color:#6b5417;
             border-radius:10px; padding:12px 16px; font-size:13px; margin-bottom:26px; line-height:1.7; }}
  .dir {{ background:var(--card); border:1px solid var(--line); border-radius:16px;
          padding:24px; margin-bottom:22px; }}
  .dir h2 {{ font-size:18px; margin:0 0 5px; letter-spacing:-0.01em; }}
  .concept {{ margin:0 0 18px; font-size:13px; color:var(--muted); line-height:1.6; }}
  .tiles {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(228px,1fr)); gap:14px; }}
  .tile {{ margin:0; }}
  .tile figcaption {{ font-size:12px; color:var(--muted); margin-top:8px; }}
  .scene {{ border-radius:10px; overflow:hidden; display:flex; align-items:center;
            justify-content:center; border:1px solid var(--line); }}
  .scene svg {{ display:block; }}

  /* 包装：纸底，竖版袋形 */
  .pack {{ background:#f0e6d6; height:190px; padding:0; }}
  .pouch {{ width:128px; height:164px; background:var(--kraft); border-radius:5px 5px 8px 8px;
            display:flex; align-items:center; justify-content:center; padding:18px 14px;
            box-shadow:0 3px 10px rgba(90,60,20,.22); }}
  .pouch > svg {{ width:100%; height:100%; }}

  /* 门头招牌：深底反白 */
  .sign {{ background:#e8eaec; height:190px; }}
  .signboard {{ width:96%; height:86px; background:var(--dark); border-radius:4px;
                display:flex; align-items:center; justify-content:center; padding:0 18px;
                box-shadow:0 4px 14px rgba(0,0,0,.28); }}
  .signboard > svg {{ width:100%; height:100%; }}

  /* 头像 + App 图标 */
  .duo {{ background:#fafbfc; height:190px; gap:16px; }}
  .avatar {{ width:96px; height:96px; border-radius:50%; background:#fff; border:1px solid var(--line);
             display:flex; align-items:center; justify-content:center; padding:14px; }}
  .appicon {{ width:96px; height:96px; border-radius:22px; background:#fff; border:1px solid var(--line);
              display:flex; align-items:center; justify-content:center; padding:16px;
              box-shadow:0 2px 8px rgba(0,0,0,.07); }}
  .avatar > svg, .appicon > svg {{ width:100%; height:100%; }}

  /* 名片 */
  .business {{ background:#eef0f2; height:190px; }}
  .card {{ width:84%; height:122px; background:#fff; border-radius:4px; padding:15px 17px;
           box-shadow:0 3px 12px rgba(0,0,0,.12); display:flex; flex-direction:column;
           justify-content:space-between; }}
  .card-logo {{ height:52px; display:flex; align-items:center; }}
  .card-logo > svg {{ max-width:100%; height:100%; width:auto; }}
  .card-lines {{ display:flex; flex-direction:column; gap:5px; }}
  .card-lines i {{ display:block; height:4px; border-radius:2px; background:#e3e6ea; width:70%; }}
  .card-lines i.short {{ width:42%; }}

  footer {{ margin-top:30px; padding-top:18px; border-top:1px solid var(--line);
            font-size:12px; color:var(--muted); line-height:1.9; }}
</style></head>
<body><div class="page">
  <div class="top">
    <h1>{esc(brand)} · 场景应用模拟</h1>
    {f'<p class="tag">{esc(tagline)}</p>' if tagline else ''}
    <div class="meta">
      <span>生成日期 {today}</span>
      <span>{len(groups)} 个方向</span>
      <span>阶段 4 决策材料</span>
    </div>
  </div>

  <div class="notice">
    <b>这是示意图，不是成品效果图。</b>场景是几何示意（包装袋、招牌、名片都是方块代替），
    用于判断<b>比例、对比度、小尺寸可读性</b>；真实的材质、灯光、印刷色需要另行打样验证。
    深底招牌用的是反白版，如果这一格看不清，说明该方向缺少可用的反白版本。
  </div>

  {body}

  <footer>
    <b>看这一版重点判断三件事</b><br>
    1. <b>门头招牌那一格</b>——3 秒内能不能认出是什么生意？认不出说明图形识别度不够。<br>
    2. <b>头像 / App 图标那一格</b>——缩到这么小还认得出吗？认不出说明需要简化版。<br>
    3. <b>名片那一格</b>——单色黑下造型是否还立得住？去掉颜色就散的方案不能定稿。<br>
    <span style="opacity:.75">本材料由 LogoPilot 程序化生成，用于方向验证；商用前请自行完成商标检索。</span>
  </footer>
</div></body></html>"""


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot 场景应用模拟板生成")
    ap.add_argument("svg_dir", help="包含 logo SVG 的目录")
    ap.add_argument("--brand", help="品牌名")
    ap.add_argument("--tagline", help="一句话定位")
    ap.add_argument("--meta", help="meta.json 路径（可选）")
    ap.add_argument("--out", default="mockup.html", help="输出 HTML 路径")
    args = ap.parse_args()

    meta: dict = {}
    if args.meta:
        meta = json.loads(Path(args.meta).read_text(encoding="utf-8"))
    if args.brand:
        meta["brand"] = args.brand
    if args.tagline:
        meta["tagline"] = args.tagline

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(build(Path(args.svg_dir), meta), encoding="utf-8")
    print(f"✔ 场景模拟板已生成：{out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
