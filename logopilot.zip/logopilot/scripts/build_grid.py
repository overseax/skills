#!/usr/bin/env python3
"""LogoPilot · 16:9 四宫格方案图生成

把 4 个方向的**纯图形**合成到一张 16:9 横版画布上，2 列 × 2 行标准网格，
四个方案的视觉尺寸、留白、重心统一。这是阶段 3 的第一眼评审物。

规范见 references/grid-sheet.md。

**默认出纯黑白版**（对齐参考工作流的规格："1672×941，16:9，纯黑白平面设计"）。
原因不是审美，是判据：形状不过关的 logo 在彩色版里会被颜色救回来，
在黑白版里立刻露馅。所以先看黑白，再看彩色。

为什么不用 viewBox 对齐：四个 mark 的包围盒天生不同（字母标偏扁、剪影偏高），
直接等大并排会看起来"有的胖有的瘦"。本脚本**实测每个 mark 的真实墨迹包围盒**
（渲染后扫 alpha 通道，含描边外扩），再按包围盒重算正方形 viewBox，
做到光学等大。

用法：
    python3 build_grid.py svg/ --out grid.png                  # 黑白版（默认）
    python3 build_grid.py svg/ --out grid.png --color-out grid-color.png
    python3 build_grid.py svg/ --out grid.png --color          # 彩色为主
    python3 build_grid.py svg/ --out grid.png --cards --labels
    python3 build_grid.py svg/ --out grid.png --size 1920x1080 --fit area
"""

from __future__ import annotations

import argparse
import html
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from render_svg import build_html, find_chrome, png_read  # noqa: E402

VIEWBOX = re.compile(r'viewBox\s*=\s*"([^"]+)"', re.IGNORECASE)
COLOR_ATTR = re.compile(r'(fill|stroke)\s*=\s*"(#[0-9A-Fa-f]{3,8})"')
SVG_OPEN = re.compile(r"<svg\b[^>]*>", re.IGNORECASE | re.DOTALL)
TITLE = re.compile(r"<title>.*?</title>", re.DOTALL)
ID_ATTR = re.compile(r'\bid="([^"]+)"')
DIR_PREFIX = re.compile(r"^(d\d+)[-_]", re.IGNORECASE)

# 变体探测顺序：长键必须在短键之前（wordmark 不能被 mark 吃掉）
MARK_ORDER = ["mark", "favicon", "primary", "lockup-horizontal", "lockup-vertical",
              "mono-black", "mono-white", "inverse", "wordmark"]

DEFAULT_SIZE = (1672, 941)

MONO_COLOR = "#111111"      # 不用纯黑 #000，印刷/屏幕上都更稳
CARD_BG = "#FFFFFF"
CARD_LINE = "#E8E8E8"
CARD_PAGE = "#FAFAFA"       # 有卡片时页面底色略灰，卡片才浮得起来


# ───────────────────────── SVG 小工具 ─────────────────────────

def read_viewbox(svg_text: str) -> list[float]:
    m = VIEWBOX.search(svg_text)
    if not m:
        raise ValueError("SVG 缺少 viewBox，无法归一化")
    parts = [float(x) for x in re.split(r"[,\s]+", m.group(1).strip()) if x]
    if len(parts) != 4:
        raise ValueError(f"viewBox 格式不对：{m.group(1)}")
    return parts


def strip_root(svg_text: str, uid: str) -> str:
    """去掉 XML 声明、根 <svg> 标签与 <title>，返回可嵌套的内部内容；id 加前缀防冲突。"""
    t = re.sub(r"<\?xml[^>]*\?>", "", svg_text).strip()
    m = SVG_OPEN.search(t)
    if not m:
        raise ValueError("找不到 <svg> 根标签")
    end = t.rindex("</svg>")
    body = t[m.end():end]
    body = TITLE.sub("", body)
    for i in sorted(set(ID_ATTR.findall(body)), key=len, reverse=True):
        safe = f"{uid}-{i}"
        body = body.replace(f'id="{i}"', f'id="{safe}"')
        body = body.replace(f"url(#{i})", f"url(#{safe})")
        body = body.replace(f'href="#{i}"', f'href="#{safe}"')
    return body


def to_mono(svg_text: str, color: str = MONO_COLOR) -> str:
    """把所有 fill/stroke 的颜色字面量换成单色（保留 fill="none"）。"""
    return COLOR_ATTR.sub(lambda m: f'{m.group(1)}="{color}"', svg_text)


def collect_marks(svg_dir: Path) -> dict[str, Path]:
    """每个方向挑一个"纯图形"文件。"""
    groups: dict[str, dict[str, Path]] = {}
    for f in sorted(svg_dir.rglob("*.svg")):
        m = DIR_PREFIX.match(f.stem)
        key = m.group(1).lower() if m else "all"
        stem = f.stem.lower()
        kind = "other"
        for k in MARK_ORDER:
            if k in stem:
                kind = k
                break
        groups.setdefault(key, {}).setdefault(kind, f)
    out = {}
    for key, kinds in groups.items():
        for k in MARK_ORDER:
            if k in kinds:
                out[key] = kinds[k]
                break
    return dict(sorted(out.items()))


# ───────────────────────── 墨迹包围盒测量 ─────────────────────────

def ink_bbox(chrome: str, svg_text: str, tmpdir: Path, probe: int = 512,
             thresh: int = 8) -> tuple[float, float, float, float]:
    """渲染后扫 alpha 通道，返回归一化墨迹包围盒 (x0, y0, x1, y1)，相对坐标 0–1。

    必须实测而不是读路径坐标：描边会让墨迹比路径外扩 stroke-width/2，
    算出来的包围盒会系统性偏小，四个 mark 就对齐不了。
    """
    hp = tmpdir / f"probe-{abs(hash(svg_text)) & 0xFFFFFF:06x}.html"
    hp.write_text(build_html(svg_text, None, 0.0, 1.0), encoding="utf-8")
    pp = hp.with_suffix(".png")
    probe = max(probe, 512)          # 无头浏览器最小窗口限制，见 render_svg.SAFE_MIN
    subprocess.run(
        [chrome, "--headless", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
         "--disable-dev-shm-usage", "--force-device-scale-factor=1",
         "--virtual-time-budget=2000", f"--window-size={probe},{probe}",
         f"--screenshot={pp}", "--default-background-color=00000000", hp.as_uri()],
        capture_output=True, text=True, timeout=60,
    )
    w, h, ch, px = png_read(pp)
    if ch != 4:
        raise ValueError("探测图不是 RGBA，无法测墨迹（请用 --bg transparent 渲染）")

    minx, miny, maxx, maxy = w, h, -1, -1
    for y in range(h):
        base = y * w * ch
        a = px[base + 3: base + w * ch: 4]          # 该行 alpha
        if max(a) <= thresh:
            continue
        lo = 0
        while a[lo] <= thresh:
            lo += 1
        hi = w - 1
        while a[hi] <= thresh:
            hi -= 1
        if lo < minx:
            minx = lo
        if hi > maxx:
            maxx = hi
        if y < miny:
            miny = y
        if y > maxy:
            maxy = y

    if maxx < 0:
        return (0.0, 0.0, 1.0, 1.0)
    return (minx / w, miny / h, (maxx + 1) / w, (maxy + 1) / h)


def normalized_viewbox(vb: list[float], bbox: tuple[float, float, float, float],
                       fill: float, fit: str = "max") -> str:
    """按墨迹包围盒重算正方形 viewBox，使墨迹在框内占比 = fill。"""
    x, y, w, h = vb
    x0, y0, x1, y1 = bbox
    ix0, iy0 = x + x0 * w, y + y0 * h
    ix1, iy1 = x + x1 * w, y + y1 * h
    iw, ih = max(ix1 - ix0, 1e-6), max(iy1 - iy0, 1e-6)
    cx, cy = (ix0 + ix1) / 2, (iy0 + iy1) / 2

    if fit == "area":
        ref = (iw * ih) ** 0.5           # 面积口径：宽高的几何平均
    else:
        ref = max(iw, ih)                # 默认口径：最长边
    side = ref / fill
    return f"{cx - side / 2:.3f} {cy - side / 2:.3f} {side:.3f} {side:.3f}"


# ───────────────────────── 合成 ─────────────────────────

def build_svg(items: list[dict], W: int, H: int, margin: int, gutter: int,
              art: int, labels: bool, grid_lines: bool, bg: str,
              cards: bool = False, body_key: str = "body") -> str:
    """纯矢量四宫格：嵌套 <svg> 各自带独立 viewBox。"""
    cell_w = (W - 2 * margin - gutter) / 2
    cell_h = (H - 2 * margin - gutter) / 2
    parts = [f'<rect width="{W}" height="{H}" fill="{bg}"/>']
    for i, it in enumerate(items):
        r, c = divmod(i, 2)
        cx = margin + c * (cell_w + gutter)
        cy = margin + r * (cell_h + gutter)
        ax = cx + (cell_w - art) / 2
        ay = cy + (cell_h - art) / 2
        if labels:
            ay = cy + (cell_h - art - 34) / 2
        if cards:
            parts.append(
                f'<rect x="{cx:.1f}" y="{cy:.1f}" width="{cell_w:.1f}" height="{cell_h:.1f}" '
                f'rx="{min(cell_w, cell_h) * 0.05:.1f}" fill="{CARD_BG}" '
                f'stroke="{CARD_LINE}" stroke-width="1.5"/>'
            )
        elif grid_lines:
            parts.append(
                f'<rect x="{cx:.1f}" y="{cy:.1f}" width="{cell_w:.1f}" height="{cell_h:.1f}" '
                f'fill="none" stroke="{CARD_LINE}" stroke-width="1"/>'
            )
        parts.append(
            f'<svg x="{ax:.1f}" y="{ay:.1f}" width="{art}" height="{art}" '
            f'viewBox="{it["viewbox"]}" overflow="visible">{it[body_key]}</svg>'
        )
        if labels:
            parts.append(
                f'<text x="{cx + cell_w / 2:.1f}" y="{ay + art + 26:.1f}" text-anchor="middle" '
                f'font-family="-apple-system,BlinkMacSystemFont,PingFang SC,sans-serif" '
                f'font-size="20" fill="#6B7280">{html.escape(it["name"])}</text>'
            )
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" role="img" aria-label="四宫格方案对比">\n  '
            + "\n  ".join(parts) + "\n</svg>\n")


def build_page(grid_svg: str, W: int, H: int, page_bg: str = "#FFFFFF") -> str:
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><style>
  html, body {{ margin:0; padding:0; width:{W}px; height:{H}px; overflow:hidden;
                background:{page_bg}; }}
  svg {{ display:block; }}
</style></head><body>{grid_svg}</body></html>"""


def shoot(chrome: str, grid_svg: str, W: int, H: int, out: Path, page_bg: str) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="logopilot-shot-") as td:
        hp = Path(td) / "grid.html"
        hp.write_text(build_page(grid_svg, W, H, page_bg), encoding="utf-8")
        subprocess.run(
            [chrome, "--headless", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
             "--disable-dev-shm-usage", "--force-device-scale-factor=1",
             "--virtual-time-budget=3000", f"--window-size={W},{H}",
             f"--screenshot={out}", "--default-background-color=FFFFFFFF", hp.as_uri()],
            capture_output=True, text=True, timeout=90,
        )
    if not out.exists() or out.stat().st_size == 0:
        raise SystemExit(f"渲染四宫格 PNG 失败：{out}")


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot 16:9 四宫格方案图生成")
    ap.add_argument("svg_dir", help="包含 logo SVG 的目录")
    ap.add_argument("--meta", help="meta.json 路径（可选，用于每格标签）")
    ap.add_argument("--out", default="grid.png", help="主输出 PNG 路径（默认 grid.png）")
    ap.add_argument("--svg-out", help="主输出的矢量版路径（默认与 PNG 同名 .svg）")
    ap.add_argument("--color", action="store_true",
                    help="主输出用彩色版（默认主输出是纯黑白版）")
    ap.add_argument("--color-out",
                    help="额外再输出一张彩色版 PNG（配合默认黑白主输出使用）")
    ap.add_argument("--size", default=f"{DEFAULT_SIZE[0]}x{DEFAULT_SIZE[1]}",
                    help="画布尺寸 WxH（默认 1672x941，16:9）")
    ap.add_argument("--fill", type=float, default=0.72,
                    help="每个 mark 占格内正方形的比例（默认 0.72）")
    ap.add_argument("--fit", choices=["max", "area"], default="max",
                    help="统一视觉尺寸的口径（默认 max：最长边等长）")
    ap.add_argument("--mono", action="store_true",
                    help="强制黑白主输出（已是默认，保留兼容）")
    ap.add_argument("--cards", action="store_true",
                    help="每格加一块浅色圆角面板（对齐参考示意图的呈现方式）")
    ap.add_argument("--labels", action="store_true", help="每格下方标注方向名")
    ap.add_argument("--grid-lines", action="store_true", help="显示格线")
    args = ap.parse_args()

    try:
        W, H = (int(v) for v in args.size.lower().split("x"))
    except ValueError:
        raise SystemExit(f"--size 格式应为 WxH，例如 1672x941（收到 {args.size}）")
    if abs(W / H - 16 / 9) > 0.02:
        print(f"⚠ 画布 {W}×{H} 不是 16:9（{W/H:.3f}），四宫格规范建议 16:9", file=sys.stderr)

    src = Path(args.svg_dir)
    if not src.is_dir():
        raise SystemExit(f"找不到目录：{src}")
    marks = collect_marks(src)
    if not marks:
        raise SystemExit(f"{src} 里没有找到 .svg 文件")

    meta: dict = {}
    if args.meta:
        meta = json.loads(Path(args.meta).read_text(encoding="utf-8"))
    dir_meta = meta.get("directions") or {}

    chrome = find_chrome()
    margin = round(min(W, H) * 0.07)
    gutter = round(min(W, H) * 0.04)
    cell_w = (W - 2 * margin - gutter) / 2
    cell_h = (H - 2 * margin - gutter) / 2
    art = round(min(cell_w, cell_h) * (0.78 if args.labels else 0.92))

    items = []
    with tempfile.TemporaryDirectory(prefix="logopilot-grid-") as td:
        tmp = Path(td)
        for key, path in marks.items():
            text = path.read_text(encoding="utf-8", errors="replace")
            # 墨迹包围盒与配色无关（to_mono 不动几何），所以只测一次、两个版本共用
            vb = read_viewbox(text)
            bbox = ink_bbox(chrome, text, tmp)
            nvb = normalized_viewbox(vb, bbox, args.fill, args.fit)
            info = dir_meta.get(key, {})
            name = info.get("name") or f"方向 {key.upper()}"
            items.append({
                "key": key,
                "name": name,
                "viewbox": nvb,
                "body": strip_root(text, key),
                "body_mono": strip_root(to_mono(text), key),
                "src": path.name,
            })
            print(f"  · {key}: {path.name}  墨迹框 {bbox[2]-bbox[0]:.2f}×{bbox[3]-bbox[1]:.2f} "
                  f"→ viewBox {nvb}")

    page_bg = CARD_PAGE if args.cards else "#FFFFFF"
    primary_mono = not args.color

    def sheet(body_key: str) -> str:
        return build_svg(items, W, H, margin, gutter, art, args.labels,
                         args.grid_lines, page_bg, args.cards, body_key)

    # ── 主输出 ──
    grid = sheet("body_mono" if primary_mono else "body")
    svg_out = Path(args.svg_out) if args.svg_out else Path(args.out).with_suffix(".svg")
    svg_out.parent.mkdir(parents=True, exist_ok=True)
    svg_out.write_text(grid, encoding="utf-8")
    out = Path(args.out)
    shoot(chrome, grid, W, H, out, page_bg)
    tag = "纯黑白" if primary_mono else "彩色"
    print(f"✔ 四宫格 SVG：{svg_out}")
    print(f"✔ 四宫格 PNG：{out}  ({W}×{H}，{tag}版)")

    # ── 附带彩色版 ──
    if args.color_out:
        cgrid = sheet("body")
        csvg = Path(args.color_out).with_suffix(".svg")
        csvg.write_text(cgrid, encoding="utf-8")
        shoot(chrome, cgrid, W, H, Path(args.color_out), page_bg)
        print(f"✔ 四宫格 SVG：{csvg}")
        print(f"✔ 四宫格 PNG：{args.color_out}  ({W}×{H}，彩色版)")

    order = " / ".join(
        f"{['左上','右上','左下','右下'][i]} {it['key'].upper()}" for i, it in enumerate(items[:4])
    )
    print(f"  顺序：{order}" if len(items) >= 4 else f"  共 {len(items)} 个方向")
    print(f"  评审顺序：先看{'黑白' if primary_mono else '彩色'}版判形状，"
          f"{'再看彩色版' if args.color_out or not primary_mono else '彩色版见阶段 6'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
