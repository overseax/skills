#!/usr/bin/env python3
"""LogoPilot · SVG 质量体检

对一批 logo SVG 做静态检查，找出会在交付后翻车的问题：
缺失 viewBox、位图残留、字体依赖、坐标噪音、节点爆炸、伪负空间等。

用法：
    python3 check_svg.py <svg文件或目录> [--strict] [--json]

退出码：有 error 时返回 1，否则 0。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

NS = "{http://www.w3.org/2000/svg}"

PATH_CMD = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]")
HEX_COLOR = re.compile(r"#[0-9a-fA-F]{3,8}\b")
DECIMAL_NOISE = re.compile(r"\d+\.\d{3,}")
TRANSFORM = re.compile(r"\b(translate|scale|rotate|matrix|skewX|skewY)\s*\(")

# 单条路径节点数上限（按整体复杂度取最宽松档）
NODE_LIMIT = 40
TOTAL_NODES_LIMIT = 220
PATH_COUNT_LIMIT = 20
COLOR_LIMIT = 3

WHITEISH = {"#fff", "#ffffff", "#FFFFFF", "white", "#FFF", "rgb(255,255,255)"}

ERROR = "error"
WARN = "warn"
INFO = "info"


def tag_of(el) -> str:
    return el.tag.split("}")[-1] if isinstance(el.tag, str) else ""


def local(t: str) -> str:
    return t.split("}")[-1]


class Result:
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[tuple[str, str]] = []
        self.stats: dict = {}

    def add(self, level: str, msg: str) -> None:
        self.findings.append((level, msg))

    @property
    def errors(self) -> int:
        return sum(1 for lv, _ in self.findings if lv == ERROR)

    @property
    def warns(self) -> int:
        return sum(1 for lv, _ in self.findings if lv == WARN)


def check_file(path: Path) -> Result:
    r = Result(path)
    raw = path.read_text(encoding="utf-8", errors="replace")

    # ---------- 解析 ----------
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        r.add(ERROR, f"XML 解析失败：{e}")
        return r

    if local(root.tag) != "svg":
        r.add(ERROR, f"根元素不是 <svg>，而是 <{local(root.tag)}>")
        return r

    # ---------- viewBox ----------
    vb = root.get("viewBox") or root.get("viewbox")
    if not vb:
        r.add(ERROR, "缺少 viewBox（无法缩放，设计师打开后尺寸不确定）")
    else:
        parts = re.split(r"[\s,]+", vb.strip())
        if len(parts) != 4:
            r.add(ERROR, f"viewBox 格式不对：{vb!r}，应为 4 个数字")
        else:
            try:
                x, y, w, h = (float(p) for p in parts)
                r.stats["viewBox"] = [x, y, w, h]
                if abs(x) > 1e-9 or abs(y) > 1e-9:
                    r.add(WARN, f"viewBox 原点不是 0 0（当前 {x:g} {y:g}），居中会变麻烦")
                if abs(w - h) > max(w, h) * 0.02:
                    r.add(
                        INFO,
                        f"viewBox 非正方形（{w:g}x{h:g}）——锁定版/字标属正常；"
                        "出 App 图标时请另用方形 mark 版",
                    )
            except ValueError:
                r.add(ERROR, f"viewBox 含非数字：{vb!r}")

    # ---------- 遍历元素 ----------
    n_path = 0
    n_nodes = 0
    max_nodes = 0
    n_text = 0
    n_image = 0
    n_filter = 0
    n_gradient = 0
    n_transform = 0
    n_transform_bakeable = 0
    n_style_attr = 0
    n_shadowish = 0
    colors: set[str] = set()
    fonts: set[str] = set()

    for el in root.iter():
        t = local(el.tag)

        if t == "path":
            n_path += 1
            d = el.get("d") or ""
            c = len(PATH_CMD.findall(d))
            n_nodes += c
            max_nodes = max(max_nodes, c)
            if c > NODE_LIMIT:
                r.add(WARN, f"单条路径 {c} 个节点（上限 {NODE_LIMIT}），可能没简化到位")
            if "C" in d.upper() and d.count("A") == 0 and c > 8 and _looks_like_circle(el):
                r.add(INFO, "疑似用贝塞尔曲线逼近圆，建议改用 A（弧）命令")
        elif t in ("rect", "circle", "ellipse", "polygon", "polyline", "line"):
            n_path += 1
        elif t == "text":
            n_text += 1
            fam = el.get("font-family") or el.get("fontFamily") or ""
            if fam:
                fonts.add(fam)
        elif t == "image":
            n_image += 1
        elif t == "filter":
            n_filter += 1
        elif t in ("linearGradient", "radialGradient"):
            n_gradient += 1

        if el.get("transform"):
            n_transform += 1
        if el.get("style"):
            n_style_attr += 1

        # 颜色采集（含 presentation attribute）
        for attr in ("fill", "stroke", "stop-color", "flood-color"):
            v = el.get(attr)
            if v and v not in ("none", "currentColor", "transparent"):
                colors.update(m.group(0).lower() for m in HEX_COLOR.finditer(v))
                if v.strip().lower() in ("white", "#fff", "#ffffff"):
                    pass

    # ---------- 关键判定 ----------
    if n_image:
        r.add(ERROR, f"含 {n_image} 个 <image> 位图元素（不是矢量，无法编辑）")
    if n_text:
        r.add(
            WARN,
            f"含 {n_text} 个 <text>，依赖字体 "
            f"[{', '.join(sorted(fonts)) if fonts else '未声明 font-family'}]，"
            "交付前需转曲或替换为已授权字体",
        )
    if n_filter or n_shadowish:
        r.add(WARN, f"含 {n_filter} 个滤镜（阴影/发光），印刷与单色场景不可用")
    if n_gradient:
        r.add(WARN, f"含 {n_gradient} 个渐变，单色与印刷场景会失效")
    if n_transform_bakeable:
        r.add(
            WARN,
            f"含 {n_transform_bakeable} 处 scale/rotate/matrix transform，"
            "几何应直接烘焙进坐标，否则改尺寸时比例会跑偏",
        )
    if n_transform - n_transform_bakeable:
        r.add(
            INFO,
            f"含 {n_transform - n_transform_bakeable} 处 translate，用于锁定版组合属正常用法，"
            "请在 HANDOFF 里注明部件来源",
        )
    if n_style_attr:
        r.add(WARN, f"含 {n_style_attr} 处内联 style，建议改用 fill=/stroke= 属性，兼容性更好")
    if n_path > PATH_COUNT_LIMIT:
        r.add(WARN, f"共 {n_path} 条图形元素（上限 {PATH_COUNT_LIMIT}），元素过多小尺寸会糊")
    if n_nodes > TOTAL_NODES_LIMIT:
        r.add(WARN, f"总节点数 {n_nodes}（上限 {TOTAL_NODES_LIMIT}），路径不够干净")
    if len(colors) > COLOR_LIMIT:
        r.add(WARN, f"用了 {len(colors)} 个颜色（建议 ≤ {COLOR_LIMIT}）：{sorted(colors)}")
    if len(colors) == 0:
        r.add(INFO, "没有显式颜色（全部继承 currentColor 或 none），请确认这是有意的")

    # 变体类型（从文件名推断），用于避免对反白/单色版误报
    stem = path.stem.lower()
    is_inverse = any(k in stem for k in ("inverse", "mono-white", "white"))
    is_mono_black = "mono-black" in stem or "monoblack" in stem

    # 伪负空间检测：纯白填充（反白版整版都是白的，跳过）
    if not is_inverse:
        white_fills = [
            el.get("fill")
            for el in root.iter()
            if (local(el.tag) in ("path", "rect", "circle", "ellipse", "polygon"))
            and (el.get("fill") or "").strip().lower() in ("#fff", "#ffffff", "white")
        ]
        if white_fills:
            r.add(
                WARN,
                f"发现 {len(white_fills)} 处白色填充，疑似用白块伪造负空间"
                '（换深色底会露馅，建议改用 fill-rule="evenodd" 真正挖空）',
            )

    # 单色版必须真的只有一个颜色
    if is_mono_black:
        non_black = [
            c
            for c in colors
            if c not in ("#000", "#000000", "#111", "#111111", "#0a0a0a", "#16181d")
        ]
        if non_black:
            r.add(
                WARN,
                f"单色黑版里还有非黑颜色 {non_black}——单色版应只用一个颜色，"
                "浅色部分请改成镂空（evenodd）而不是填浅色",
            )
    if is_inverse:
        bright = [c for c in colors if c not in ("#fff", "#ffffff", "#f7f5f0", "#fafafa")]
        if bright:
            r.add(WARN, f"反白版里还有非白颜色 {bright}，深色底上会看不清")

    # 坐标噪音
    noise = DECIMAL_NOISE.findall(raw)
    if noise:
        r.add(WARN, f"坐标精度过高（{len(noise)} 处 3 位以上小数），是机器生成的痕迹，建议四舍五入到 2 位")

    # 可访问性
    has_title = any(local(e.tag) == "title" for e in root.iter())
    has_aria = root.get("aria-label") or root.get("aria-labelledby")
    if not (has_title or has_aria):
        r.add(WARN, "缺少 <title> 或 aria-label（无障碍与 SEO 建议补上）")

    size_kb = len(raw.encode("utf-8")) / 1024
    if size_kb > 60:
        r.add(WARN, f"文件 {size_kb:.1f} KB，logo 应该远小于这个体积")

    r.stats.update(
        {
            "elements": n_path,
            "total_nodes": n_nodes,
            "max_path_nodes": max_nodes,
            "text": n_text,
            "image": n_image,
            "colors": sorted(colors),
            "size_kb": round(size_kb, 2),
        }
    )
    return r


def _looks_like_circle(el) -> bool:
    d = el.get("d") or ""
    # 4 段 C 命令、首尾坐标接近 → 疑似手绘圆
    return d.upper().count("C") == 4 and d.upper().count("Z") >= 1


def iter_svgs(target: Path):
    if target.is_file() and target.suffix.lower() == ".svg":
        yield target
    elif target.is_dir():
        yield from sorted(target.rglob("*.svg"))
    else:
        raise SystemExit(f"找不到 SVG 文件或目录：{target}")


ICON = {ERROR: "ERROR", WARN: "WARN ", INFO: "INFO "}


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot SVG 质量体检")
    ap.add_argument("target", help="SVG 文件或目录")
    ap.add_argument("--strict", action="store_true", help="把 warn 也视为失败")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    files = list(iter_svgs(Path(args.target)))
    if not files:
        print("没有找到任何 .svg 文件")
        return 1

    results = [check_file(f) for f in files]

    if args.json:
        print(
            json.dumps(
                {
                    "files": [
                        {
                            "path": str(r.path),
                            "errors": r.errors,
                            "warns": r.warns,
                            "stats": r.stats,
                            "findings": [{"level": lv, "msg": m} for lv, m in r.findings],
                        }
                        for r in results
                    ]
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        total_e = total_w = 0
        for r in results:
            mark = "FAIL" if r.errors else ("WARN" if r.warns else "PASS")
            print(f"\n=== [{mark}] {r.path.name} ===")
            if r.stats:
                s = r.stats
                print(
                    f"    元素 {s.get('elements')} · 总节点 {s.get('total_nodes')} · "
                    f"最大单路径 {s.get('max_path_nodes')} · 颜色 {len(s.get('colors', []))} · "
                    f"{s.get('size_kb')} KB"
                )
            if not r.findings:
                print("    ✔ 无问题")
            for lv, msg in r.findings:
                print(f"    [{ICON[lv]}] {msg}")
            total_e += r.errors
            total_w += r.warns

        print(f"\n---- 汇总：{len(results)} 个文件，{total_e} 个 error，{total_w} 个 warn ----")
        if total_e == 0:
            print("可以进入方向板生成（阶段 3 → 出板）。")
        else:
            print("存在 error，必须先修复再出板。")

    if args.strict:
        return 1 if any(r.errors or r.warns for r in results) else 0
    return 1 if any(r.errors for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
