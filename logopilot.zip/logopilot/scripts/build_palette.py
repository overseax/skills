#!/usr/bin/env python3
"""LogoPilot · 阶段 6 · 配色方案对比板

把同一批 mark 换成多套配色，排成矩阵，**同时出浅底和深底两张**——
配色必须成对验证：浅底好看不代表深底能用，反之亦然。

为什么是矩阵而不是"每个方向一套色"：配色是**品牌级**的，不是方向级的。
四个方向套同一套色，才能看出"这套色到底撑不撑得起这个品牌"。
如果某套色在 D1 好看、在 D3 就塌了，那说明这套色的明度关系不成立，
不是 D3 的问题。

依赖 `meta.json` 里每个方向的 `palette.c1` / `palette.c2`：
- `c1` = 主体色（面积大、承载识别）
- `c2` = 强调色（面积小、点睛）
阶段 3 出图时必须把这两个字段写进 meta.json，否则本脚本无法换色。

用法：
    python3 build_palette.py svg/ --meta meta.json --out palette.html
    python3 build_palette.py svg/ --meta meta.json --out palette.html \
        --png-light palette-light.png --png-dark palette-dark.png
    python3 build_palette.py svg/ --meta meta.json --palettes my-colors.json --out palette.html
"""

from __future__ import annotations

import argparse
import html
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_grid import read_viewbox, strip_root  # noqa: E402
from render_svg import find_chrome  # noqa: E402

HEX = re.compile(r"#[0-9A-Fa-f]{6}")

# 内置四套配色。每套必须给：浅底(c1/c2) + 深底(inv_bg/inv1/inv2)。
# 设计原则：四套要在**色相、明度关系、温度**三个维度上真正分开，
# 不能是"同一个绿换四个明度"——那是四套，不是一套。
PALETTES = [
    {
        "name": "松墨绿 · 鹿茸金",
        "note": "自然 / 沉稳 / 滋补感（当前基线）",
        "c1": "#1A3A2E", "c2": "#C98A3C",
        "inv_bg": "#14251E", "inv1": "#F2F6F2", "inv2": "#D9A24A",
    },
    {
        "name": "鹿茸棕 · 玄褐",
        "note": "手作 / 温度 / C 端亲和",
        "c1": "#8C5A2B", "c2": "#3E2413",
        "inv_bg": "#3A2415", "inv1": "#F7EFE4", "inv2": "#D9A86A",
    },
    {
        "name": "玄墨 · 晓霞绯",
        "note": "现代 / 克制 /「春晓」日出",
        "c1": "#241F1E", "c2": "#C4553F",
        "inv_bg": "#1B1614", "inv1": "#F7F2ED", "inv2": "#E2705A",
    },
    {
        "name": "靛青 · 苔绿",
        "note": "清冷 / 国际化 / 差异化",
        # c2 从 #7FA88B 调深到 #5E8C6A：原先在浅底上当细描边（D2 的环）时明显发灰发虚，
        # 撑不住"强调色"的角色。强调色是**点睛**，浅底上必须站得住。
        "c1": "#22343C", "c2": "#5E8C6A",
        "inv_bg": "#16242A", "inv1": "#EAF1F3", "inv2": "#9CC4A8",
    },
]

MARK_ORDER = ["mark", "favicon", "primary", "lockup-horizontal", "lockup-vertical",
              "mono-black", "mono-white", "inverse", "wordmark"]
DIR_PREFIX = re.compile(r"^(d\d+)[-_]", re.IGNORECASE)

CELL_W, CELL_H = 300, 250
LABEL_W = 300
MARGIN = 44
# ⚠️ HEADER 必须容得下"主标题 + 副标题 + 列头"三层。之前取 78，
#   列头的 y = MARGIN+HEADER-22 = 100，正好和副标题 y = MARGIN+58 = 102 撞在一起，
#   D1/D2 的列头被副标题盖住。改成 116 后留出 40 单位间隙。
HEADER = 116


def pick_mark(svg_dir: Path, key: str) -> Path:
    """挑该方向的纯图形文件（与 build_grid 同规则）。"""
    cands = [f for f in sorted(svg_dir.rglob(f"{key}-*.svg"))]
    for kind in MARK_ORDER:
        for f in cands:
            if kind in f.stem.lower():
                return f
    if not cands:
        raise SystemExit(f"找不到 {key}-*.svg")
    return cands[0]


def recolor(svg_text: str, src: tuple[str, str], dst: tuple[str, str]) -> str:
    """按原色 → 新色做精确替换。大小写不敏感。"""
    def sub(m: re.Match) -> str:
        v = m.group(0)
        for s, d in zip(src, dst):
            if s.lower() == v.lower():
                return d
        return v
    return HEX.sub(sub, svg_text)


def load_marks(svg_dir: Path, meta: dict) -> list[dict]:
    out = []
    for key in sorted((meta.get("directions") or {}).keys()):
        info = meta["directions"][key]
        pal = info.get("palette") or {}
        if not (pal.get("c1") and pal.get("c2")):
            raise SystemExit(
                f"meta.json 里 {key} 缺少 palette.c1 / palette.c2，无法换色。\n"
                f"阶段 3 出图时必须写入这两个字段（见 SKILL.md 阶段 6）。")
        path = pick_mark(svg_dir, key)
        text = path.read_text(encoding="utf-8", errors="replace")
        out.append({
            "key": key,
            "name": info.get("name") or key.upper(),
            "src": (pal["c1"], pal["c2"]),
            "viewbox": " ".join(f"{v:.3f}" for v in read_viewbox(text)),
            "body": strip_root(text, key),
            "file": path.name,
        })
    if not out:
        raise SystemExit("meta.json 里没有 directions")
    return out


def build_matrix(marks: list[dict], palettes: list[dict], dark: bool,
                 title: str) -> tuple[str, int, int]:
    ncol, nrow = len(marks), len(palettes)
    W = MARGIN * 2 + LABEL_W + ncol * CELL_W
    H = MARGIN * 2 + HEADER + nrow * CELL_H
    bg = "#FFFFFF" if not dark else "#0E0E0E"
    title_fg = "#111111" if not dark else "#F5F5F5"
    sub_fg = "#6B7280" if not dark else "#9CA3AF"

    parts = [f'<rect width="{W}" height="{H}" fill="{bg}"/>']
    parts.append(
        f'<text x="{MARGIN}" y="{MARGIN + 30}" font-family="-apple-system,BlinkMacSystemFont,'
        f'PingFang SC,sans-serif" font-size="30" font-weight="600" fill="{title_fg}">'
        f'{html.escape(title)}</text>')
    parts.append(
        f'<text x="{MARGIN}" y="{MARGIN + 58}" font-family="-apple-system,BlinkMacSystemFont,'
        f'PingFang SC,sans-serif" font-size="16" fill="{sub_fg}">'
        f'配色是品牌级的，不是方向级的 —— 四个方向套同一套色，才能看出这套色撑不撑得起品牌</text>')

    # 列头（方向名）
    for c, m in enumerate(marks):
        cx = MARGIN + LABEL_W + c * CELL_W + CELL_W / 2
        parts.append(
            f'<text x="{cx:.0f}" y="{MARGIN + HEADER - 22}" text-anchor="middle" '
            f'font-family="-apple-system,BlinkMacSystemFont,PingFang SC,sans-serif" '
            f'font-size="17" font-weight="600" fill="{title_fg}">{html.escape(m["key"].upper())}</text>')

    for r, pal in enumerate(palettes):
        ry = MARGIN + HEADER + r * CELL_H
        # 每套配色的行底：浅底用纯白，深底用该套的 inv_bg（这样能看出"深色底是不是也该带品牌色"）
        row_bg = pal["inv_bg"] if dark else "#FFFFFF"
        row_line = "#262626" if dark else "#EFEFEF"
        parts.append(
            f'<rect x="{MARGIN}" y="{ry:.0f}" width="{W - 2 * MARGIN}" height="{CELL_H}" '
            f'rx="14" fill="{row_bg}" stroke="{row_line}" stroke-width="1"/>')
        parts.append(
            f'<text x="{MARGIN + 28}" y="{ry + 44:.0f}" '
            f'font-family="-apple-system,BlinkMacSystemFont,PingFang SC,sans-serif" '
            f'font-size="22" font-weight="600" fill="{title_fg}">{html.escape(pal["name"])}</text>')
        parts.append(
            f'<text x="{MARGIN + 28}" y="{ry + 72:.0f}" '
            f'font-family="-apple-system,BlinkMacSystemFont,PingFang SC,sans-serif" '
            f'font-size="15" fill="{sub_fg}">{html.escape(pal["note"])}</text>')
        # 色票
        sw = [pal["inv1"], pal["inv2"]] if dark else [pal["c1"], pal["c2"]]
        for i, c_hex in enumerate(sw):
            parts.append(
                f'<rect x="{MARGIN + 28 + i * 96}" y="{ry + 92:.0f}" width="82" height="34" '
                f'rx="8" fill="{c_hex}"/>')
            parts.append(
                f'<text x="{MARGIN + 28 + i * 96}" y="{ry + 148:.0f}" '
                f'font-family="ui-monospace,SFMono-Regular,Menlo,monospace" '
                f'font-size="13" fill="{sub_fg}">{c_hex.upper()}</text>')

        for c, m in enumerate(marks):
            src = m["src"]
            dst = (pal["inv1"], pal["inv2"]) if dark else (pal["c1"], pal["c2"])
            body = recolor(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{m["viewbox"]}">'
                           f'{m["body"]}</svg>', src, dst)
            body = strip_root(body, f'{m["key"]}-{r}')
            art = int(min(CELL_W, CELL_H) * 0.62)
            ax = MARGIN + LABEL_W + c * CELL_W + (CELL_W - art) / 2
            ay = ry + (CELL_H - art) / 2 + 12
            parts.append(
                f'<svg x="{ax:.1f}" y="{ay:.1f}" width="{art}" height="{art}" '
                f'viewBox="{m["viewbox"]}" overflow="visible">{body}</svg>')

    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
            f'width="{W}" height="{H}" role="img" aria-label="{html.escape(title)}">\n  '
            + "\n  ".join(parts) + "\n</svg>\n"), W, H


def build_page(svg_text: str, W: int, H: int, bg: str) -> str:
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><style>
  html,body{{margin:0;padding:0;background:{bg};}}
  svg{{display:block;max-width:100%;height:auto;}}
</style></head><body>{svg_text}</body></html>"""


def shoot(chrome: str, svg_text: str, W: int, H: int, out: Path, bg: str) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="logopilot-pal-") as td:
        hp = Path(td) / "p.html"
        hp.write_text(build_page(svg_text, W, H, bg), encoding="utf-8")
        subprocess.run(
            [chrome, "--headless", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
             "--disable-dev-shm-usage", "--force-device-scale-factor=1",
             "--virtual-time-budget=4000", f"--window-size={W},{H}",
             f"--screenshot={out}", f"--default-background-color="
             f"{'FFFFFFFF' if bg == '#FFFFFF' else 'FF0E0E0E'}", hp.as_uri()],
            capture_output=True, text=True, timeout=120,
        )
    if not out.exists() or out.stat().st_size == 0:
        raise SystemExit(f"渲染失败：{out}")


def main() -> int:
    ap = argparse.ArgumentParser(description="LogoPilot 阶段 6 · 配色方案对比板")
    ap.add_argument("svg_dir")
    ap.add_argument("--meta", required=True)
    ap.add_argument("--out", default="palette.html")
    ap.add_argument("--png-light", help="浅底对比板 PNG 路径")
    ap.add_argument("--png-dark", help="深底对比板 PNG 路径")
    ap.add_argument("--palettes", help="自定义配色 JSON（数组，字段同内置）")
    ap.add_argument("--brand", help="覆盖标题里的品牌名")
    args = ap.parse_args()

    src = Path(args.svg_dir)
    if not src.is_dir():
        raise SystemExit(f"找不到目录：{src}")
    meta = json.loads(Path(args.meta).read_text(encoding="utf-8"))
    marks = load_marks(src, meta)
    palettes = json.loads(Path(args.palettes).read_text(encoding="utf-8")) if args.palettes else PALETTES

    brand = args.brand or meta.get("brand") or "品牌"
    print(f"  换色契约：{len(marks)} 个方向 × {len(palettes)} 套配色")
    for m in marks:
        print(f"    · {m['key']}: {m['file']}  原色 {m['src'][0]} / {m['src'][1]}")

    light_svg, W, H = build_matrix(marks, palettes, False, f"{brand} · 配色方案对比（浅底）")
    dark_svg, _, _ = build_matrix(marks, palettes, True, f"{brand} · 配色方案对比（深底反白）")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    page = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{html.escape(brand)} 配色对比</title><style>
  body{{margin:0;background:#F4F4F5;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;}}
  .wrap{{padding:28px;}}
  .sec{{background:#fff;border-radius:16px;padding:18px;margin-bottom:26px;
        box-shadow:0 1px 3px rgba(0,0,0,.08);overflow:auto;}}
  .sec.dark{{background:#0E0E0E;}}
  h2{{font-size:15px;letter-spacing:.04em;color:#6B7280;margin:0 0 12px;font-weight:600;}}
  .sec.dark h2{{color:#9CA3AF;}}
</style></head><body><div class="wrap">
<div class="sec"><h2>浅底 · 四套配色 × 四个方向</h2>{light_svg}</div>
<div class="sec dark"><h2>深底反白 · 同一批方案</h2>{dark_svg}</div>
</div></body></html>"""
    out.write_text(page, encoding="utf-8")
    print(f"✔ 配色对比板：{out}")

    chrome = find_chrome()
    if args.png_light:
        shoot(chrome, light_svg, W, H, Path(args.png_light), "#FFFFFF")
        print(f"✔ 浅底 PNG：{args.png_light}  ({W}×{H})")
    if args.png_dark:
        shoot(chrome, dark_svg, W, H, Path(args.png_dark), "#0E0E0E")
        print(f"✔ 深底 PNG：{args.png_dark}  ({W}×{H})")

    print("  怎么读：先横着看一行（一套色在四个方向上是否都站得住），")
    print("          再竖着看一列（同一个方向在哪套色里最像它自己）。")
    print("  一行里有任何一个塌了，这套色的明度关系就不成立——"
          "不要用「这个方向不合适」去解释。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
